package AppointmentServicePackage;
import AppointmentServicePackage.Appointment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AppointmentService {
	
    private List<Appointment> appointmentsList = new ArrayList<>();
    
    //create unique appointment ID
    public String createID() {
    	return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
    }
    
    //create empty constructor
    public void newAppointment() {
    	Appointment apt = new Appointment(createID());
    	appointmentsList.add(apt);
    }
    
    //constructor taking date
    public void newAppointment(Date date) {
    	Appointment apt = new Appointment(createID(), date);
    	appointmentsList.add(apt);
    }
    
    //constructor taking date and description
    public void newAppointment(Date date, String descApp) {
    	Appointment apt = new Appointment(createID(), date, descApp);
    	appointmentsList.add(apt);
    }
    
    //method to delete an appointment using ID
    public void deleteAppt(String id) {
    	appointmentsList.remove(searchAppointment(id));
    }
    
    
    //method to search appointment list
    public Appointment searchAppointment(String id) {
    	int i = 0;
    	while(i < appointmentsList.size()) {
    		if(id.equals(appointmentsList.get(i).getApptID())) {
    			return appointmentsList.get(i);
    		}
    		i++;
    	}
         //throw if entire list is searched without returning 
    	throw new IllegalArgumentException("No appointment found with that ID.");
    }
    
    //method to return appointment list ::: used for testing
    public List<Appointment> getApptList() {
    	return appointmentsList;
    }
}	

