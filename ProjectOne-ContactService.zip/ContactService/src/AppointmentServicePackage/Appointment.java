package AppointmentServicePackage;

import java.util.Date;

public class Appointment {
	
	private String appointmentID;
	private Date appointmentDate;
	private String apptDescr;
	
	//empty appointment constructor
	public Appointment(){
		appointmentID = null;
		appointmentDate = null;
		apptDescr = null;
	}
	//appointment constructor taking ID
	public Appointment(String id){
		setApptID(id);
		appointmentDate = null;
		apptDescr = null;
	}
	//appointment constructor taking id and date
	public Appointment(String id, Date date){
		setApptID(id);
		setApptDate(date);
		apptDescr = null;
	}
	//appointment constructor w/ all parameters
	public Appointment(String id, Date date, String descr){
		setApptID(id);
		setApptDate(date);
		setApptDescr(descr);
	}
	
	//set appointment ID
	public void setApptID(String id) {
		if (id == null) {
			throw new IllegalArgumentException("ID field is empty.");
		}
		else if (id.length() > 10) {
			throw new IllegalArgumentException("ID may not exceed 10 characters.");
		}
		else {
			this.appointmentID = id;
		}
	}
	
	//set appointment date
	public void setApptDate(Date date) {
		if(date == null) {
			throw new IllegalArgumentException("Date field is empty.");
		}
		else if(date.before(new Date())) {
			throw new IllegalArgumentException("Date cannot be in the past.");
		}
		else {
			this.appointmentDate = date;
		}
	}
	
	//set appointment description
	public void setApptDescr(String descr) {
		if(descr == null) {
			throw new IllegalArgumentException("Description field is empty.");
		}
		else if(descr.length() > 50){
				throw new IllegalArgumentException("Description may not exceed 50 characters in length.");
		}
		else {
			this.apptDescr = descr;
		}
	}
	
	//return appointment id
	public String getApptID() {
		return appointmentID;
	}
	
	//return appointment date
	public Date getApptDate() {
		return appointmentDate;
	}
	
	//return appointment description
	public String getApptDescr() {
		return apptDescr;
	}
		

}//end appointment class
