package ContactServicePackage;

public class Contact {
	private String userID;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	
	//constructor for empty contact
	public Contact() {
		this.userID = null;
		this.firstName = null;
		this.lastName = null;
		this.number = null;
		this.address = null;
	}
	
	//constructor for contact with only ID
	public Contact(String userID) {
		setUserID(userID);
		this.firstName = null;
		this.lastName = null;
		this.number = null;
		this.address = null;
	}
	
	//constructor for contact with ID and first name
	public Contact(String userID, String firstName){
		setUserID(userID);
		setFirstName(firstName);
		this.lastName = null;
		this.number = null;
		this.address = null;
	}
	
	//constructor for contact with userID, first name, last name
	public Contact(String userID, String firstName, String lastName){
		setUserID(userID);
		setFirstName(firstName);
		setLastName(lastName);
		this.number = null;
		this.address = null;
	}
	
	//constructor for contact w/ ID, first name, last name, number
	public Contact(String userID, String firstName, String lastName, String number){
		setUserID(userID);
		setFirstName(firstName);
		setLastName(lastName);
		setNumber(number);
		this.address = null;
	}
	
	//constructor for contact with all values
	public Contact(String userID, String firstName, String lastName, String number, String address){
		setUserID(userID);
		setFirstName(firstName);
		setLastName(lastName);
		setNumber(number);
		setAddress(address);
	}
	
	//set unique user ID	
	public void setUserID(String userID) {
		//if user ID does not meet conditions, print error statement
		if (userID == null || userID.length() > 10) {
			throw new IllegalArgumentException("Invalid user ID.");
		}
		//else: assign user ID
		else {
			this.userID = userID;
		}
			
	}
	

	//set first name
	public void setFirstName(String firstName) {
		//if first name does not meet conditions print error statement
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name.");
		}
		//else: assign first name
		else {
		    this.firstName = firstName;
		}
	}
	
	//set last name
	public void setLastName(String lastName) {
		//if last name does not meet conditions print error statement
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name.");
		}
		//else: assign last name
		else {
		    this.lastName = lastName;
		}
	}
	
	//set phone number
	public void setNumber(String number) {
		//if number meets conditions assign number
		if (number.length() == 10) {
		    this.number = number;
		}
		//else: number does not meet conditions, print error statement
		else {
			throw new IllegalArgumentException("Invalid phone number.");
		}
	}
	
	//set address
	public void setAddress(String address) {
		//if address does not meet conditions, print error statement
		if (address.length() == 0 || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address.");
		}
		//else: assign address
		else {
		    this.address = address;
		}
	}
	
	//get user ID
	public String getUserID() {
		return userID;
	}
	
	//get first name
	public String getFirstName() {
		return firstName;
	}
	
	//get last name
	public String getLastName() {
		return lastName;
	}
	
	//get number
	public String getNumber() {
		return number;		
	}
	
	//get address
	public String getAddress() {
		return address;
	}
	
	
}
