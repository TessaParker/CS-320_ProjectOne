package TaskServicePackage;

public class Task  {
	String taskID;
	String taskName;
	String taskDescription;
	
	//empty task constructor:: DO I EVEN NEED THIS?
	public Task () {
		taskID = null;
		taskName = null;
		taskDescription = null;
	}
	
	////constructor with only task ID
	public Task (String taskID) {
		checkTaskID(taskID);
		taskName = null;
		taskDescription = null;
	}
	
	//constructor with taskID and taskName
	public Task  (String taskID, String taskName) {
		checkTaskID(taskID);
		setTaskName(taskName);
		taskDescription = null;		
	}
	
	//constructor with all parameters
	public Task (String taskID, String taskName, String taskDescription){
		checkTaskID(taskID);
		setTaskName(taskName);
		setTaskDescription(taskDescription);
	}
	
	//check task ID (task ID will be created in taskService)
	public void checkTaskID(String taskID) {
		if (taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Invalid task ID.");
		}
		else {
			this.taskID = taskID;
		}
	}
	
	//set taskName
	public void setTaskName(String taskName) {
		if(taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid task name.");
		}
		else {
			this.taskName = taskName;
		}
	}
	
	//set taskDescription
	public void setTaskDescription(String taskDescription) {
		if (taskDescription == null || taskDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid task description.");
		}
		else {
			this.taskDescription = taskDescription;
		}
	}
	
	//get task id
	public String getTaskID() {
		return taskID;
	}
	
	//get task name
	public String getTaskName() {
		return taskName;
	}
	
	//get task description
	public String getTaskDescription() {
		return taskDescription;
	}

}
