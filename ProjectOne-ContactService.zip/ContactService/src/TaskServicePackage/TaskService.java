package TaskServicePackage;

import java.util.ArrayList;

import java.util.List;
import java. util. UUID;

import TaskServicePackage.Task;

public class TaskService {
	private List<Task> taskList = new ArrayList<>();
	String taskID;
	
	//create unique task ID
	String createTaskID() {
		//use UUID to generate a unique ID
		taskID = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
		return taskID;
	}
	
	//ALL TASKS MUST HAVE ID
	//create new empty task
	public void newTask() {
		Task task = new Task(createTaskID());
		taskList.add(task);
	}
	
	//create task with name
	public void newTask(String taskName) {
		Task task = new Task(createTaskID(), taskName);
		taskList.add(task);
	}
	
	//create task with all parameters
	public void newTask(String taskName, String taskDescription) {
		Task task = new Task(createTaskID(), taskName, taskDescription);
		taskList.add(task);
	}
	
	//create method to search task list
	public Task searchTaskList(String taskID) throws Exception {
		int i = 0;
		//loop through list until id is found
		while( i < taskList.size()) {
			if (taskID == taskList.get(i).getTaskID()) {
				return taskList.get(i);
			}
			//increment index
			i++;
		}
		throw new Exception("Task not found in list.");
	}
	
	//create method to delete task
	public void removeTask(String taskID) throws Exception {
		taskList.remove(searchTaskList(taskID));
	}
	
	//create method to update name
	public void updateTaskName(String taskID, String taskName) throws Exception {
		searchTaskList(taskID).setTaskName(taskName);
	}
	
	//create method to update task description
	public void updateTaskDescription(String taskID, String taskDescription) throws Exception {
		searchTaskList(taskID).setTaskDescription(taskDescription);
	}
	
	//create method to return task list
	public List<Task> returnTaskList(){
		return taskList;
	}


}//end taskService class
