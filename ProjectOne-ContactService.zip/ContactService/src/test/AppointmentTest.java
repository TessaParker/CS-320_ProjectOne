package test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import AppointmentServicePackage.Appointment;

class AppointmentTest {
	
	public String id;
	public String apptDescr;
	public String badID;
	public String badApptDescr;
	public Date date;
	public Date badDate;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() {
		
		id = "0123456789";
		apptDescr = "Appointment made for lip waxing";
		date = new Date(2029,Calendar.MAY, 6);
		
		badID = "5421354687987516654687";
		badApptDescr = "This appointment description is very very very very very very veeeeeery long";
		badDate = new Date(0);
	}
	
	
	@Test
	//test empty appointment constructor
	void testEmptyAppt() {
		Appointment appt = new Appointment();		
	}

	@Test
	//test set appointment ID
	void testSetApptID() {
		Appointment appt = new Appointment(id);
		assertEquals(id, appt.getApptID());
		assertThrows(IllegalArgumentException.class, ()-> appt.setApptID(null));
		assertThrows(IllegalArgumentException.class, () -> appt.setApptID(badID));
		
	}
	
	@Test
	//test set appointment date
	void testSetApptDate() {
		Appointment appt = new Appointment(id, date);
		assertEquals(date, appt.getApptDate());
		assertThrows(IllegalArgumentException.class, ()-> appt.setApptDate(null));
		assertThrows(IllegalArgumentException.class, ()-> appt.setApptDate(badDate));
		
	}
	
	@Test
	//test set appointment description
	void testSetApptDescr() {
		Appointment appt = new Appointment(id, date, apptDescr);
		assertEquals(apptDescr, appt.getApptDescr());
		assertThrows(IllegalArgumentException.class, ()-> appt.setApptDescr(null));
		assertThrows(IllegalArgumentException.class, ()-> appt.setApptDescr(badApptDescr));
	}
	
	@Test
	//test get appointment ID
	void testGetApptID() {
		Appointment appt = new Appointment(id);
		assertNotNull(appt.getApptID());
		assertEquals(id, appt.getApptID());
	}
	
	@Test
	//test get appointment date
	void testGetApptDate() {
		Appointment appt = new Appointment(id, date);
		assertNotNull(appt.getApptDate());
		assertEquals(date, appt.getApptDate());
	}
	
	@Test
	//test get appointment description
	void testGetApptDescr() {
		Appointment appt = new Appointment(id, date, apptDescr);
		assertNotNull(appt.getApptDescr());
		assertEquals(apptDescr, appt.getApptDescr());
	}

}
