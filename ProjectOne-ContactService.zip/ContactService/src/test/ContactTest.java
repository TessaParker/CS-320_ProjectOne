package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ContactServicePackage.Contact;


class ContactTest {
	private String userID;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	
	private String badUserID;
	private String badFirstName;
	private String badLastName;
	private String badNumber;
	private String badAddress;
	

	@BeforeEach
	void setUp() {
		userID = "Brutes94";
		firstName = "Tessa";
		lastName = "Potato";
		number = "0123456789";
		address = "Not So Easy Street";
		
		badUserID = "This ID is longer than 10 characters!";
		badFirstName = "This first name is also longer than 10 characters!";
		badLastName = "This last name is definitely longer than allowed!";
		badNumber = "0123456789876543210";
		badAddress = "Cruising on easy street without a care in the world. It's a beautiful day in smalltown USA";
	}

	@Test
	void emptyContactTest() {
		//create new contact object
		Contact user = new Contact();
		//assert all fields
		assertAll("constructor", 
				()-> assertNull(user.getUserID()),
			    ()-> assertNull(user.getFirstName()),
			    ()-> assertNull(user.getLastName()), 
			    ()-> assertNull(user.getNumber()),
			    ()-> assertNull(user.getAddress()));				
	}
	
	@Test
	void userIDContactTest() {
		//create new contact object
		Contact user = new Contact(userID);
		//assert all fields
		assertAll("constructor w/ ID", 
				()-> assertEquals(userID, user.getUserID()),
				()-> assertNull(user.getFirstName()),
				()-> assertNull(user.getLastName()), 
				()-> assertNull(user.getNumber()),
				()-> assertNull(user.getAddress()));
	}
	
	@Test
	void userFirstNameContactTest() {
		//create new contact object
		Contact user = new Contact(userID, firstName);
		//assert all fields
		assertAll("constructor w/ ID, first name", 
				 ()-> assertEquals(userID, user.getUserID()),
				 ()-> assertEquals(firstName, user.getFirstName()),
				 ()-> assertNull(user.getLastName()), 
				 ()-> assertNull(user.getNumber()),
				 ()-> assertNull(user.getAddress()));
	}
	
	@Test
	void userLastNameContactTest() {
		//create new contact object
		Contact user = new Contact(userID, firstName, lastName);
		//assert all fields
		assertAll("constructor w/ ID, first name, last name", 
				()-> assertEquals(userID, user.getUserID()),
				()-> assertEquals(firstName, user.getFirstName()),
				()-> assertEquals(lastName, user.getLastName()), 
				()-> assertNull(user.getNumber()),
				()-> assertNull(user.getAddress()));
	}
	
	@Test
	void userNumberContactTest() {
		//create new contact object
		Contact user = new Contact(userID, firstName, lastName, number);
		//assert all fields
		assertAll("constructor w/ ID, first name, last name, number", 
				()-> assertEquals(userID, user.getUserID()),
				()-> assertEquals(firstName, user.getFirstName()),
				()-> assertEquals(lastName, user.getLastName()),
				()-> assertEquals(number, user.getNumber()),
				()-> assertNull(user.getAddress()));
				
	}
	
	@Test
	void userAddressContactTest() {
		//create new contact object
		Contact user = new Contact(userID, firstName, lastName, number, address);
		//assert all fields
		assertAll("constructor w/ ID, first name, last name, number, address", 
				()-> assertEquals(userID, user.getUserID()),
				()-> assertEquals(firstName, user.getFirstName()),
				()-> assertEquals(lastName, user.getLastName()),
				()-> assertEquals(number, user.getNumber()),
				()-> assertEquals(address, user.getAddress()));
				
	}
	
	@Test
	//use incorrect User ID
	void badUserIDContactTest() {
		assertThrows(IllegalArgumentException.class, ()-> new Contact(badUserID));
	}
	
	@Test
	//use incorrect first name
	void badUserFirstNameTest() {
		assertThrows(IllegalArgumentException.class, ()-> new Contact(userID, badFirstName));
	}
	
	@Test
	//use incorrect last name
	void badLastNameTest() {
		assertThrows(IllegalArgumentException.class, ()-> new Contact(userID, firstName, badLastName));
	}
	
	@Test
	//use incorrect phone number
	void badNumberTest() {
		assertThrows(IllegalArgumentException.class, ()-> new Contact(userID, firstName, lastName, badNumber));
	}
	
	@Test
	//use incorrect address
	void badAddressTest() {
		assertThrows(IllegalArgumentException.class, ()-> new Contact(userID, firstName, lastName, number, badAddress));
	}
	
	

}//end ContactTest
