package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import TaskServicePackage.Task;

class TaskTest {
	String taskID;
	String taskName;
	String taskDescription;
	
	String badTaskID;
	String badTaskName;
	String badTaskDescription;

	@BeforeEach
	void setUp() {
	//assign variables for each test	
	taskID = "task123";
	taskName = "doesThing";
	taskDescription = "Does that thing! You know which one.";
	
	badTaskID = "sdf48e698435s7er84684sfesfe";
	badTaskName = "ThisTaskRocksHarderThanYourMom";
	badTaskDescription = "This task is the ultimate task. Some even say this task is the best task that ever existed. The importance of this task cannot be exxagerated. ";
	}

	@Test
	//test empty constructor
	void taskIDTest() {
		//create task object
		Task task = new Task();
		//assert that values are assigned as expected
		assertAll("Constructor with ID", 
				()-> assertNull(task.getTaskID()),
				()-> assertNull(task.getTaskName()),
				()-> assertNull(task.getTaskDescription()));						
	}		
	
	@Test
	//test set task id method
	void checkTaskIDTest() {
		Task task = new Task(taskID);
		task.checkTaskID(task.getTaskID());		
	}
	
	@Test
	//test set name method
	void setTaskNameTest() {
		Task task = new Task(taskID, taskName);
		task.setTaskName(taskName);
		assertEquals(taskName, task.getTaskName());		
	}
	
	@Test
	//test set description method
	void setTaskDescriptionTest() {
		Task task = new Task(taskID, taskName, taskDescription);
		task.setTaskDescription(taskDescription);
		assertEquals(taskDescription, task.getTaskDescription());		
	}
	
	@Test
	//test get id method
	void getTaskIDTest() {
		Task task = new Task(taskID);
		assertEquals(taskID, task.getTaskID());
	}
	
	@Test
	//test get name method
	void getTaskNameTest() {
		Task task = new Task(taskID, taskName);
		assertEquals(taskName, task.getTaskName());
	}
	
	@Test
	//test get description method
	void getTaskDescriptionTest() {
		Task task = new Task(taskID, taskName, taskDescription);
		assertEquals(taskDescription, task.getTaskDescription());
	}
	
	@Test
	//assert that exception is thrown for invalid task ID
	void badTaskIDTest() {
		assertThrows(IllegalArgumentException.class, ()-> new Task(badTaskID));
	}
	
	@Test
	//assert that exception is thrown for invalid task name
	void badTaskNameTest() {
		assertThrows(IllegalArgumentException.class, ()-> new Task(taskID, badTaskName));
	}
	
	@Test
	//assert that exception is thrown for invalid task description
	void badTaskDescriptionTest() {
		assertThrows(IllegalArgumentException.class, ()-> new Task(taskID, taskName, badTaskDescription));
	}
	

}//end TaskTest class
