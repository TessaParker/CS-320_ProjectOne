package test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import AppointmentServicePackage.AppointmentService;

class AppointmentServiceTest {
	
	public String id;
	public String apptDescr;
	public String badID;
	public String badApptDescr;
	public Date date;
	public Date badDate;


	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		id = "0123456789";
		apptDescr = "Appointment made for lip waxing";
		date = new Date(2029,Calendar.MAY, 6);
		
		badID = "5421354687987516654687";
		badApptDescr = "This appointment description is very very very very very very veeeeeery long";
		badDate = new Date(0);
	}

	@Test
	//test new appointment creation and addition to list
	void testNewAppt() {
		AppointmentService srv = new AppointmentService();
		//test empty new appointment method
		srv.newAppointment();
		assertNotNull(srv.getApptList().get(0));

		//test new appointment method taking date
		srv.newAppointment(date);
		assertNotNull(srv.getApptList().get(1));
		
		//test new appointment method taking all parameters
		srv.newAppointment(date, apptDescr);
		assertNotNull(srv.getApptList().get(2));

	}
	
	@Test
	//test method to search list and delete appointment **(delete appointment method provides coverage of searchAppointment method)**
	void testDeleteAppt() {
		AppointmentService srv = new AppointmentService();
		//populate the list
		srv.newAppointment();
		srv.newAppointment();
		srv.newAppointment();
		//search for id that is not present
		assertThrows(IllegalArgumentException.class, ()-> srv.deleteAppt(id));
		//get the id of first item in list (and assign to variable
		String listID = srv.getApptList().get(0).getApptID();
		//delete first item in list
		srv.deleteAppt(listID);		
	}

}
