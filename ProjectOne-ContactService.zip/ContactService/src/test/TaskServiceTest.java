package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import TaskServicePackage.TaskService;

class TaskServiceTest {
	
	String taskID;
	String taskName;
	String taskDescription;
	

	@BeforeEach
	void setUp() {
		taskID = "task123";
		taskName = "doesThing";
		taskDescription = "Does that thing! You know which one.";
	}
	

	@Test
	//test new task creation taking no parameters
	void newTaskTest() {
		TaskService task = new TaskService();
		task.newTask();
		assertNotNull(task.returnTaskList().get(0).getTaskID());		
	}
	
	@Test
	//test new task creation w/ name parameter
	void newTaskNameTest() {
		TaskService task = new TaskService();
		task.newTask(taskName);
		assertNotNull(task.returnTaskList().get(0).getTaskName());
	}
	
	@Test
	//test new task creation with description parameter
	void newTaskDescTest() {
		TaskService task = new TaskService();
		task.newTask(taskName, taskDescription);
		assertNotNull(task.returnTaskList().get(0).getTaskDescription());
	}
	
	@Test
	//test delete task method
	void removeTaskTest() throws Exception {
		TaskService task = new TaskService();
		task.newTask(taskName, taskDescription);
		assertEquals(1, task.returnTaskList().size());
		task.removeTask(task.returnTaskList().get(0).getTaskID());
		assertEquals(0, task.returnTaskList().size());
	}
	
	@Test
	//test update task name method
	void updateTaskNameTest() throws Exception {
		TaskService task = new TaskService();
		task.newTask();
		task.updateTaskName(task.returnTaskList().get(0).getTaskID(), taskName);
		assertEquals(taskName, task.returnTaskList().get(0).getTaskName());
	}
	
	@Test
	//test update description method
	void updateTaskDescriptionTest() throws Exception {
		TaskService task = new TaskService();
		task.newTask();
		task.updateTaskDescription(task.returnTaskList().get(0).getTaskID(), taskDescription);
		assertEquals(taskDescription, task.returnTaskList().get(0).getTaskDescription());
	}
	
	@Test
	//test search list method
	void searchTaskListTest() throws Exception {
		TaskService task = new TaskService();
		task.newTask();
		task.newTask();
		assertNotNull(task.searchTaskList(task.returnTaskList().get(1).getTaskID()));
	}
	
	@Test
	//**** This test unit passes in testing, but does not show coverage of exception (in TaskService Class) in a coverage run??****
	//test search list method with empty list
	void searchEmptyTaskList() throws Exception {
		TaskService task = new TaskService();
		//search for an item in list that does not exist to check for exception
		assertThrows(Exception.class, ()-> task.searchTaskList(task.returnTaskList().get(0).getTaskID()));
		//having difficulty with 'throws', confirmed that size of list is zero
		assertEquals(0, task.returnTaskList().size());
	}

}//end TaskServiceTest Class
