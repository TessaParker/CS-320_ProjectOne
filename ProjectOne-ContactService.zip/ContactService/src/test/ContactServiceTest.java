package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ContactServicePackage.ContactService;

class ContactServiceTest {
	
	private String userID;
	private String firstName;
	private String lastName;
	private String number;
	private String address;

	@BeforeEach
	void setUp() {
		userID = "Brutes94";
		firstName = "Tessa";
		lastName = "Potato";
		number = "0123456789";
		address = "Not So Easy Street";
	}

	@Test
	//test add contact methods
	void newContactTest() {
		//create new contact service object
		ContactService testService = new ContactService();
		//add empty contact
		testService.newContact();
		assertAll("testService1", 
				()-> assertNotNull(testService.getContactsList().get(0).getUserID()),
				()-> assertNull(testService.getContactsList().get(0).getFirstName()),
				()-> assertNull(testService.getContactsList().get(0).getLastName()),
				()-> assertNull(testService.getContactsList().get(0).getNumber()),
				()-> assertNull(testService.getContactsList().get(0).getAddress()));				
		//add first name
		testService.newContact(firstName);
		assertAll("testService2", 
				()-> assertNotNull(testService.getContactsList().get(1).getUserID()),
				()-> assertNotNull(testService.getContactsList().get(1).getFirstName()),
				()-> assertNull(testService.getContactsList().get(1).getLastName()),
				()-> assertNull(testService.getContactsList().get(1).getNumber()),
				()-> assertNull(testService.getContactsList().get(1).getAddress()));				
        //add last name
		testService.newContact(firstName, lastName);
		assertAll("testService3", 
				()-> assertNotNull(testService.getContactsList().get(2).getUserID()),
				()-> assertNotNull(testService.getContactsList().get(2).getFirstName()),
				()-> assertNotNull(testService.getContactsList().get(2).getLastName()),
				()-> assertNull(testService.getContactsList().get(2).getNumber()),
				()-> assertNull(testService.getContactsList().get(2).getAddress()));
		//add number
		testService.newContact(firstName, lastName, number);
		assertAll("testService4", 
				()-> assertNotNull(testService.getContactsList().get(3).getUserID()),
				()-> assertNotNull(testService.getContactsList().get(3).getFirstName()),
				()-> assertNotNull(testService.getContactsList().get(3).getLastName()),
				()-> assertNotNull(testService.getContactsList().get(3).getNumber()),
				()-> assertNull(testService.getContactsList().get(3).getAddress()));
		//add address
		testService.newContact(firstName, lastName, number, address);
		assertAll("testService3", 
				()-> assertNotNull(testService.getContactsList().get(4).getUserID()),
				()-> assertNotNull(testService.getContactsList().get(4).getFirstName()),
				()-> assertNotNull(testService.getContactsList().get(4).getLastName()),
				()-> assertNotNull(testService.getContactsList().get(4).getNumber()),
				()-> assertNotNull(testService.getContactsList().get(4).getAddress()));
	}
	
	@Test
	//test remove contact method
	void removeContactTest() {
		//create new contact service object
		ContactService testService = new ContactService();
		//add contact to list
		testService.newContact(firstName, lastName, number, address);
		//remove contact from list
		testService.removeContact(userID);		
	}
	
	@Test
	//test search contact list method
	void searchContactsListTest() {
		//create new contact service object
		ContactService serviceTest = new ContactService();
		//create new contact for list
		serviceTest.newContact(firstName, lastName, number, address);
		//search for contact
		serviceTest.searchContactsList(userID);
		
	}
	
	@Test
	//test update first name method
	void updateFirstNameTest() {
		//create new contact service object
		ContactService serviceTest = new ContactService();
		//create new contact for list
		serviceTest.newContact(firstName, lastName, number, address);
		//call update first name
		serviceTest.updateFirstName(serviceTest.getContactsList().get(0).getUserID(), firstName);
	}
	
	@Test
	//test update last name
	void updateLastNameTest() {
		//create new contact service object
		ContactService serviceTest = new ContactService();
		//create new contact for list
		serviceTest.newContact(firstName, lastName, number, address);
		//call update first name
		serviceTest.updateLastName(serviceTest.getContactsList().get(0).getUserID(), lastName);
	}
	
	@Test
	//test update number method
	void updateNumberTest() {
		//create new contact service object
		ContactService serviceTest = new ContactService();
		//create new contact for list
		serviceTest.newContact(firstName, lastName, number, address);
		//call update first name
		serviceTest.updateNumber(serviceTest.getContactsList().get(0).getUserID(), number);
	}
	
	@Test
	//test update address method
	void updateAddressTest() {
		//create new contact service object
		ContactService serviceTest = new ContactService();
		//create new contact for list
		serviceTest.newContact(firstName, lastName, number, address);
		//call update first name
		serviceTest.updateAddress(serviceTest.getContactsList().get(0).getUserID(), address);
	}
}
