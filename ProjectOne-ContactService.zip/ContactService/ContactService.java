package ContactServicePackage;
import java.util.ArrayList;
import java.util.List;
import java. util. UUID;



public class ContactService {
	
	private List<Contact> contactsList = new ArrayList<>();
	private String userID;
	
	//create randomized user ID
	String createUserID(){
		userID = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
		return userID;
	}
	
	//ALL CONTACT OBJECTS MUST HAVE USER ID
	//create empty contact object.
	public void newContact() {
		Contact user = new Contact(createUserID());
		contactsList.add(user);
	}
	
	//create new contact, pass first name
	public void newContact(String firstName) {
		Contact user = new Contact(createUserID(), firstName);
		contactsList.add(user);
	}
	
	//create new contact, pass first name, last name
	public void newContact(String firstName, String lastName) {
		Contact user = new Contact(createUserID(), firstName, lastName);
		contactsList.add(user);
	}
		
	//create new contact, pass first name, last name, number
	public void newContact(String firstName, String lastName, String number) {
		Contact user = new Contact(createUserID(), firstName, lastName, number);
		contactsList.add(user);
	}
	
	//create new contact, pass first name, last name, number and address
	public void newContact(String firstName, String lastName, String number, String address) {
		Contact user = new Contact(createUserID(), firstName, lastName, number, address);
		contactsList.add(user);
	}
		
	//find contact in the list via userID
	public Contact searchContactsList(String userID) {
		int i = 0;
		//loop through list until id is found
		while( i < contactsList.size()) {
			if (userID == contactsList.get(i).getUserID()) {
				return contactsList.get(i);
			}
			//increment index
			i++;
		}
		return null;
	}
	
	//delete a contact using user id
	public void removeContact(String userID) {
		contactsList.remove(searchContactsList(userID));
	}	
	
	//return contacts list
	public List<Contact> getContactsList() {
		return contactsList;
	}
	
	/// UPDATE CONTACT INFO:
	///--------------------------
	
	//update first name
	public void updateFirstName(String userID, String firstName) {
		//find contact in list and call set first name function
		searchContactsList(userID).setFirstName(firstName);
	}
	
	//update last name
	public void updateLastName(String userID, String lastName) {
		//find contact in list and call setLastName
		searchContactsList(userID).setLastName(lastName);
	}
	
	//update number
	public void updateNumber(String userID, String number) {
		//find contact in list and call setNumber
		searchContactsList(userID).setNumber(number);
	}
	
	//update address
	public void updateAddress(String userID, String address) {
		//find contact in list and call setAddress
		searchContactsList(userID).setAddress(address);
	}

}
